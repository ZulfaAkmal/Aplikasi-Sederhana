<?php

declare(strict_types=1);

header('Content-Type: application/json; charset=utf-8');

require_once __DIR__ . '/../config/database.php';

function responseJson(bool $success, string $message, mixed $data = null, int $status = 200): never
{
    http_response_code($status);

    $response = [
        'success' => $success,
        'message' => $message,
    ];

    if ($data !== null) {
        $response['data'] = $data;
    }

    echo json_encode($response, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function getJsonBody(): array
{
    $raw = file_get_contents('php://input');

    if ($raw === false || trim($raw) === '') {
        responseJson(false, 'Body request tidak boleh kosong.', null, 400);
    }

    $data = json_decode($raw, true);

    if (!is_array($data)) {
        responseJson(false, 'Format JSON tidak valid.', null, 400);
    }

    return $data;
}

function validateProduct(array $data): array
{
    $name = trim((string)($data['name'] ?? ''));
    $price = $data['price'] ?? null;

    if ($name === '') {
        responseJson(false, 'Nama produk wajib diisi.', null, 422);
    }

    if (mb_strlen($name) > 120) {
        responseJson(false, 'Nama produk maksimal 120 karakter.', null, 422);
    }

    if ($price === null || $price === '' || !is_numeric($price)) {
        responseJson(false, 'Harga produk harus berupa angka.', null, 422);
    }

    $price = (float)$price;

    if ($price < 0) {
        responseJson(false, 'Harga produk tidak boleh negatif.', null, 422);
    }

    return [
        'name' => $name,
        'price' => $price,
    ];
}

$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
$id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT, [
    'options' => ['min_range' => 1]
]);

try {
    switch ($method) {
        case 'GET':
            if ($id !== false && $id !== null) {
                $stmt = $pdo->prepare('SELECT id, name, price, created_at, updated_at FROM products WHERE id = ?');
                $stmt->execute([$id]);
                $product = $stmt->fetch();

                if (!$product) {
                    responseJson(false, 'Produk tidak ditemukan.', null, 404);
                }

                responseJson(true, 'Produk berhasil diambil.', $product);
            }

            $stmt = $pdo->query('SELECT id, name, price, created_at, updated_at FROM products ORDER BY id DESC');
            $products = $stmt->fetchAll();

            responseJson(true, 'Daftar produk berhasil diambil.', $products);
            break;

        case 'POST':
            $data = validateProduct(getJsonBody());

            $stmt = $pdo->prepare('INSERT INTO products (name, price) VALUES (?, ?)');
            $stmt->execute([$data['name'], $data['price']]);

            $newId = (int)$pdo->lastInsertId();

            $stmt = $pdo->prepare('SELECT id, name, price, created_at, updated_at FROM products WHERE id = ?');
            $stmt->execute([$newId]);
            $product = $stmt->fetch();

            responseJson(true, 'Produk berhasil ditambahkan.', $product, 201);
            break;

        case 'PUT':
            if ($id === false || $id === null) {
                responseJson(false, 'ID produk wajib diberikan.', null, 400);
            }

            $data = validateProduct(getJsonBody());

            $stmt = $pdo->prepare('SELECT id FROM products WHERE id = ?');
            $stmt->execute([$id]);

            if (!$stmt->fetch()) {
                responseJson(false, 'Produk tidak ditemukan.', null, 404);
            }

            $stmt = $pdo->prepare('UPDATE products SET name = ?, price = ? WHERE id = ?');
            $stmt->execute([$data['name'], $data['price'], $id]);

            $stmt = $pdo->prepare('SELECT id, name, price, created_at, updated_at FROM products WHERE id = ?');
            $stmt->execute([$id]);
            $product = $stmt->fetch();

            responseJson(true, 'Produk berhasil diperbarui.', $product);
            break;

        case 'DELETE':
            if ($id === false || $id === null) {
                responseJson(false, 'ID produk wajib diberikan.', null, 400);
            }

            $stmt = $pdo->prepare('DELETE FROM products WHERE id = ?');
            $stmt->execute([$id]);

            if ($stmt->rowCount() === 0) {
                responseJson(false, 'Produk tidak ditemukan.', null, 404);
            }

            responseJson(true, 'Produk berhasil dihapus.');
            break;

        default:
            header('Allow: GET, POST, PUT, DELETE');
            responseJson(false, 'Method tidak didukung.', null, 405);
    }
} catch (Throwable $e) {
    responseJson(false, 'Terjadi kesalahan pada server.', null, 500);
}
