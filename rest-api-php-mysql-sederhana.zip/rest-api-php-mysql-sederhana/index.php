<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CRUD Produk - REST API PHP</title>
    <link rel="stylesheet" href="assets/style.css">
</head>
<body>
    <main class="container">
        <section class="card">
            <div class="header">
                <div>
                    <p class="eyebrow">Belajar REST API</p>
                    <h1>CRUD Produk</h1>
                    <p class="subtitle">Native PHP + MySQL + JavaScript Fetch API</p>
                </div>
                <span class="badge">REST API</span>
            </div>

            <form id="productForm" class="form-grid">
                <input type="hidden" id="productId">

                <div class="field">
                    <label for="name">Nama Produk</label>
                    <input type="text" id="name" maxlength="120" placeholder="Contoh: Laptop" required>
                </div>

                <div class="field">
                    <label for="price">Harga</label>
                    <input type="number" id="price" min="0" step="0.01" placeholder="Contoh: 7500000" required>
                </div>

                <div class="actions">
                    <button type="submit" id="submitButton">Simpan Produk</button>
                    <button type="button" id="cancelButton" class="secondary hidden">Batal Edit</button>
                </div>
            </form>

            <div id="message" class="message hidden"></div>
        </section>

        <section class="card">
            <div class="table-header">
                <div>
                    <h2>Daftar Produk</h2>
                    <p class="subtitle">Data diambil melalui endpoint REST API.</p>
                </div>
                <button type="button" id="refreshButton" class="secondary">Muat Ulang</button>
            </div>

            <div class="table-wrap">
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Nama</th>
                            <th>Harga</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody id="productTableBody">
                        <tr>
                            <td colspan="4" class="empty">Memuat data...</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </section>
    </main>

    <script src="assets/app.js"></script>
</body>
</html>
