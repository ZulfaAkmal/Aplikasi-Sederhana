const API_URL = 'api/products.php';

const form = document.getElementById('productForm');
const productIdInput = document.getElementById('productId');
const nameInput = document.getElementById('name');
const priceInput = document.getElementById('price');
const submitButton = document.getElementById('submitButton');
const cancelButton = document.getElementById('cancelButton');
const refreshButton = document.getElementById('refreshButton');
const tableBody = document.getElementById('productTableBody');
const messageBox = document.getElementById('message');

function formatRupiah(value) {
    return new Intl.NumberFormat('id-ID', {
        style: 'currency',
        currency: 'IDR',
        maximumFractionDigits: 0
    }).format(Number(value));
}

function escapeHtml(value) {
    return String(value)
        .replaceAll('&', '&amp;')
        .replaceAll('<', '&lt;')
        .replaceAll('>', '&gt;')
        .replaceAll('"', '&quot;')
        .replaceAll("'", '&#039;');
}

function showMessage(text, type = 'success') {
    messageBox.textContent = text;
    messageBox.className = `message ${type}`;
}

function hideMessage() {
    messageBox.textContent = '';
    messageBox.className = 'message hidden';
}

function resetForm() {
    form.reset();
    productIdInput.value = '';
    submitButton.textContent = 'Simpan Produk';
    cancelButton.classList.add('hidden');
}

function startEdit(product) {
    productIdInput.value = product.id;
    nameInput.value = product.name;
    priceInput.value = product.price;
    submitButton.textContent = 'Update Produk';
    cancelButton.classList.remove('hidden');
    nameInput.focus();
    hideMessage();
}

async function request(url, options = {}) {
    const response = await fetch(url, options);
    const result = await response.json();

    if (!response.ok || !result.success) {
        throw new Error(result.message || 'Request gagal.');
    }

    return result;
}

async function loadProducts() {
    tableBody.innerHTML = '<tr><td colspan="4" class="empty">Memuat data...</td></tr>';

    try {
        const result = await request(API_URL);
        renderProducts(result.data || []);
    } catch (error) {
        tableBody.innerHTML = `<tr><td colspan="4" class="empty">${escapeHtml(error.message)}</td></tr>`;
    }
}

function renderProducts(products) {
    if (!products.length) {
        tableBody.innerHTML = '<tr><td colspan="4" class="empty">Belum ada data produk.</td></tr>';
        return;
    }

    tableBody.innerHTML = products.map(product => `
        <tr>
            <td>${product.id}</td>
            <td>${escapeHtml(product.name)}</td>
            <td>${formatRupiah(product.price)}</td>
            <td class="row-actions">
                <button type="button" class="small" data-action="edit" data-id="${product.id}">Edit</button>
                <button type="button" class="small danger" data-action="delete" data-id="${product.id}">Hapus</button>
            </td>
        </tr>
    `).join('');
}

form.addEventListener('submit', async event => {
    event.preventDefault();
    hideMessage();

    const id = productIdInput.value.trim();
    const name = nameInput.value.trim();
    const price = priceInput.value.trim();

    const method = id ? 'PUT' : 'POST';
    const url = id ? `${API_URL}?id=${encodeURIComponent(id)}` : API_URL;

    submitButton.disabled = true;

    try {
        const result = await request(url, {
            method,
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ name, price })
        });

        showMessage(result.message, 'success');
        resetForm();
        await loadProducts();
    } catch (error) {
        showMessage(error.message, 'error');
    } finally {
        submitButton.disabled = false;
    }
});

cancelButton.addEventListener('click', () => {
    resetForm();
    hideMessage();
});

refreshButton.addEventListener('click', loadProducts);

tableBody.addEventListener('click', async event => {
    const button = event.target.closest('button[data-action]');
    if (!button) return;

    const id = button.dataset.id;
    const action = button.dataset.action;

    if (action === 'edit') {
        try {
            const result = await request(`${API_URL}?id=${encodeURIComponent(id)}`);
            startEdit(result.data);
        } catch (error) {
            showMessage(error.message, 'error');
        }
        return;
    }

    if (action === 'delete') {
        const confirmed = window.confirm('Yakin ingin menghapus produk ini?');
        if (!confirmed) return;

        try {
            const result = await request(`${API_URL}?id=${encodeURIComponent(id)}`, {
                method: 'DELETE'
            });

            showMessage(result.message, 'success');
            resetForm();
            await loadProducts();
        } catch (error) {
            showMessage(error.message, 'error');
        }
    }
});

loadProducts();
