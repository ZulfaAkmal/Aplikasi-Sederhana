# REST API PHP + MySQL Sederhana

Project belajar CRUD sederhana menggunakan:

- Native PHP 8+
- MySQL
- PDO
- HTML + CSS
- JavaScript Fetch API

## Endpoint

- `GET api/products.php` — ambil semua produk
- `GET api/products.php?id=1` — ambil satu produk
- `POST api/products.php` — tambah produk
- `PUT api/products.php?id=1` — ubah produk
- `DELETE api/products.php?id=1` — hapus produk

Contoh body untuk POST/PUT:

```json
{
  "name": "Monitor",
  "price": 2500000
}
```

## Menjalankan di XAMPP

1. Salin folder `rest-api-php-mysql-sederhana` ke `htdocs`.
2. Jalankan Apache dan MySQL.
3. Buka phpMyAdmin.
4. Import file `database.sql`.
5. Pastikan konfigurasi database di `config/database.php` sesuai dengan MySQL lokal.
6. Buka:

`http://localhost/rest-api-php-mysql-sederhana/`

## Catatan

Project ini sengaja dibuat sederhana untuk belajar. Belum mencakup autentikasi, authorization, pagination, rate limiting, logging, dan dokumentasi OpenAPI.
