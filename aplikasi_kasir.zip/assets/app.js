const state = {
    products: [],
    cart: []
};

const $ = (selector) => document.querySelector(selector);

const rupiah = (number) => new Intl.NumberFormat('id-ID', {
    style: 'currency',
    currency: 'IDR',
    maximumFractionDigits: 0
}).format(number);

async function request(url, options = {}) {
    const response = await fetch(url, {
        headers: {
            'Content-Type': 'application/json',
            ...(options.headers || {})
        },
        ...options
    });

    const data = await response.json();

    if (!response.ok || data.success === false) {
        throw new Error(data.message || 'Terjadi kesalahan.');
    }

    return data;
}

function showToast(message, type = 'success') {
    const toast = $('#toast');
    toast.textContent = message;
    toast.className = `toast ${type}`;

    clearTimeout(showToast.timer);
    showToast.timer = setTimeout(() => {
        toast.className = 'toast hidden';
    }, 2500);
}

async function loadProducts() {
    try {
        const result = await request('api/products.php');
        state.products = result.data;
        renderProducts();
        renderProductTable();
        renderCart();
    } catch (error) {
        showToast(error.message, 'error');
    }
}

function getProductImage(name) {
    const normalized = name.toLowerCase();

    const imageMap = {
        'nasi goreng': 'https://images.unsplash.com/photo-1512058564366-18510be2db19?auto=format&fit=crop&w=600&q=80',
        'mie ayam': 'https://images.unsplash.com/photo-1552611052-33e04de081de?auto=format&fit=crop&w=600&q=80',
        'es teh': 'https://images.unsplash.com/photo-1556679343-c7306c1976bc?auto=format&fit=crop&w=600&q=80',
        'kopi susu': 'https://images.unsplash.com/photo-1495474472287-4d71bcdd2085?auto=format&fit=crop&w=600&q=80',
        'roti bakar': 'https://images.unsplash.com/photo-1509440159596-0249088772ff?auto=format&fit=crop&w=600&q=80',
        'air mineral': 'https://images.unsplash.com/photo-1523362628745-0c100150b504?auto=format&fit=crop&w=600&q=80'
    };

    return imageMap[normalized] ||
        'https://images.unsplash.com/photo-1547592180-85f173990554?auto=format&fit=crop&w=600&q=80';
}

function renderProducts() {
    const keyword = $('#productSearch').value.trim().toLowerCase();
    const products = state.products.filter((product) =>
        product.name.toLowerCase().includes(keyword)
    );

    const grid = $('#productGrid');

    if (!products.length) {
        grid.innerHTML = '<div class="empty-state">Produk tidak ditemukan.</div>';
        return;
    }

    grid.innerHTML = products.map((product) => {
        const imageUrl = getProductImage(product.name);

        return `
            <button type="button" class="product-card" data-product-id="${product.id}">
                <img
                    class="product-image"
                    src="${imageUrl}"
                    alt="${escapeHtml(product.name)}"
                    loading="lazy"
                    referrerpolicy="no-referrer"
                >
                <span class="product-name">${escapeHtml(product.name)}</span>
                <strong>${rupiah(Number(product.price))}</strong>
            </button>
        `;
    }).join('');

    grid.querySelectorAll('.product-card').forEach((button) => {
        button.addEventListener('click', () => {
            const product = state.products.find(
                (item) => Number(item.id) === Number(button.dataset.productId)
            );
            addToCart(product);
        });
    });
}

function addToCart(product) {
    if (!product) return;

    const id = Number(product.id);
    const existing = state.cart.find((item) => item.id === id);

    if (existing) {
        existing.qty += 1;
    } else {
        state.cart.push({
            id,
            name: product.name,
            price: Number(product.price),
            qty: 1
        });
    }

    renderCart();
}

function updateCartQty(id, delta) {
    const item = state.cart.find((product) => product.id === id);
    if (!item) return;

    item.qty += delta;

    if (item.qty <= 0) {
        state.cart = state.cart.filter((product) => product.id !== id);
    }

    renderCart();
}

function removeFromCart(id) {
    state.cart = state.cart.filter((product) => product.id !== id);
    renderCart();
}

function getTotal() {
    return state.cart.reduce(
        (total, item) => total + (item.price * item.qty),
        0
    );
}

function renderCart() {
    const container = $('#cartItems');

    if (!state.cart.length) {
        container.innerHTML = '<div class="empty-state">Belum ada produk dipilih.</div>';
    } else {
        container.innerHTML = state.cart.map((item) => `
            <div class="cart-item">
                <div>
                    <strong>${escapeHtml(item.name)}</strong>
                    <small>${rupiah(item.price)} × ${item.qty}</small>
                </div>
                <div class="cart-actions">
                    <button type="button" data-action="minus" data-id="${item.id}">−</button>
                    <span>${item.qty}</span>
                    <button type="button" data-action="plus" data-id="${item.id}">+</button>
                    <button type="button" class="remove" data-action="remove" data-id="${item.id}">×</button>
                </div>
            </div>
        `).join('');
    }

    $('#cartTotal').textContent = rupiah(getTotal());
    updateChange();
}

function updateChange() {
    const total = getTotal();
    const payment = Number($('#payment').value || 0);
    const change = payment >= total ? payment - total : 0;

    $('#change').textContent = rupiah(change);
}

async function checkout() {
    const total = getTotal();
    const payment = Number($('#payment').value || 0);

    if (!state.cart.length) {
        showToast('Tambahkan produk ke keranjang terlebih dahulu.', 'error');
        return;
    }

    if (payment < total) {
        showToast('Uang pembeli belum mencukupi.', 'error');
        return;
    }

    try {
        const result = await request('api/checkout.php', {
            method: 'POST',
            body: JSON.stringify({
                cart: state.cart.map((item) => ({
                    id: item.id,
                    qty: item.qty
                })),
                payment
            })
        });

        showToast(`Transaksi #${result.transaction_id} berhasil disimpan.`);
        state.cart = [];
        $('#payment').value = '';
        renderCart();
        await loadTransactions();
    } catch (error) {
        showToast(error.message, 'error');
    }
}

function renderProductTable() {
    const wrap = $('#productTableWrap');

    if (!state.products.length) {
        wrap.innerHTML = '<div class="empty-state">Belum ada produk.</div>';
        return;
    }

    wrap.innerHTML = `
        <div class="table-scroll">
            <table>
                <thead>
                    <tr>
                        <th>Nama Produk</th>
                        <th>Harga</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    ${state.products.map((product) => `
                        <tr>
                            <td>${escapeHtml(product.name)}</td>
                            <td>${rupiah(Number(product.price))}</td>
                            <td class="table-actions">
                                <button type="button" class="secondary-btn edit-product" data-id="${product.id}">Edit</button>
                                <button type="button" class="danger-btn delete-product" data-id="${product.id}">Hapus</button>
                            </td>
                        </tr>
                    `).join('')}
                </tbody>
            </table>
        </div>
    `;

    wrap.querySelectorAll('.edit-product').forEach((button) => {
        button.addEventListener('click', () => {
            openProductModal(Number(button.dataset.id));
        });
    });

    wrap.querySelectorAll('.delete-product').forEach((button) => {
        button.addEventListener('click', () => {
            deleteProduct(Number(button.dataset.id));
        });
    });
}

function openProductModal(id = null) {
    const product = id
        ? state.products.find((item) => Number(item.id) === id)
        : null;

    $('#modalTitle').textContent = product ? 'Edit Produk' : 'Tambah Produk';
    $('#productId').value = product ? product.id : '';
    $('#productName').value = product ? product.name : '';
    $('#productPrice').value = product ? product.price : '';

    $('#productModal').classList.remove('hidden');
    $('#productName').focus();
}

function closeProductModal() {
    $('#productModal').classList.add('hidden');
    $('#productForm').reset();
    $('#productId').value = '';
}

async function saveProduct(event) {
    event.preventDefault();

    const id = Number($('#productId').value);
    const payload = {
        name: $('#productName').value.trim(),
        price: Number($('#productPrice').value)
    };

    try {
        await request('api/products.php', {
            method: id ? 'PUT' : 'POST',
            body: JSON.stringify(id ? { ...payload, id } : payload)
        });

        closeProductModal();
        await loadProducts();
        showToast(id ? 'Produk berhasil diperbarui.' : 'Produk berhasil ditambahkan.');
    } catch (error) {
        showToast(error.message, 'error');
    }
}

async function deleteProduct(id) {
    const product = state.products.find((item) => Number(item.id) === id);
    if (!product) return;

    if (!confirm(`Hapus produk "${product.name}"?`)) return;

    try {
        await request('api/products.php', {
            method: 'DELETE',
            body: JSON.stringify({ id })
        });

        removeFromCart(id);
        await loadProducts();
        showToast('Produk berhasil dihapus.');
    } catch (error) {
        showToast(error.message, 'error');
    }
}

async function loadTransactions() {
    try {
        const result = await request('api/transactions.php');
        renderTransactionTable(result.data);
    } catch (error) {
        showToast(error.message, 'error');
    }
}

function renderTransactionTable(transactions) {
    const wrap = $('#transactionTableWrap');

    if (!transactions.length) {
        wrap.innerHTML = '<div class="empty-state">Belum ada transaksi.</div>';
        return;
    }

    wrap.innerHTML = `
        <div class="table-scroll">
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Waktu</th>
                        <th>Total</th>
                        <th>Pembayaran</th>
                        <th>Kembalian</th>
                    </tr>
                </thead>
                <tbody>
                    ${transactions.map((transaction) => `
                        <tr>
                            <td>#${transaction.id}</td>
                            <td>${escapeHtml(transaction.created_at)}</td>
                            <td>${rupiah(Number(transaction.total))}</td>
                            <td>${rupiah(Number(transaction.payment))}</td>
                            <td>${rupiah(Number(transaction.change_amount))}</td>
                        </tr>
                    `).join('')}
                </tbody>
            </table>
        </div>
    `;
}

function switchView(viewName) {
    document.querySelectorAll('.nav-btn').forEach((button) => {
        button.classList.toggle('active', button.dataset.view === viewName);
    });

    document.querySelectorAll('.view').forEach((view) => {
        view.classList.toggle('active', view.id === `view-${viewName}`);
    });

    if (viewName === 'transaksi') {
        loadTransactions();
    }
}

function escapeHtml(value) {
    return String(value)
        .replaceAll('&', '&amp;')
        .replaceAll('<', '&lt;')
        .replaceAll('>', '&gt;')
        .replaceAll('"', '&quot;')
        .replaceAll("'", '&#039;');
}

document.addEventListener('DOMContentLoaded', () => {
    document.querySelectorAll('.nav-btn').forEach((button) => {
        button.addEventListener('click', () => switchView(button.dataset.view));
    });

    $('#productSearch').addEventListener('input', renderProducts);
    $('#payment').addEventListener('input', updateChange);
    $('#checkoutBtn').addEventListener('click', checkout);

    $('#clearCart').addEventListener('click', () => {
        state.cart = [];
        renderCart();
    });

    $('#cartItems').addEventListener('click', (event) => {
        const button = event.target.closest('button[data-action]');
        if (!button) return;

        const id = Number(button.dataset.id);
        const action = button.dataset.action;

        if (action === 'plus') updateCartQty(id, 1);
        if (action === 'minus') updateCartQty(id, -1);
        if (action === 'remove') removeFromCart(id);
    });

    $('#addProductBtn').addEventListener('click', () => openProductModal());
    $('#closeModal').addEventListener('click', closeProductModal);
    $('#cancelModal').addEventListener('click', closeProductModal);
    $('#productForm').addEventListener('submit', saveProduct);

    $('#productModal').addEventListener('click', (event) => {
        if (event.target === $('#productModal')) {
            closeProductModal();
        }
    });

    loadProducts();
});
