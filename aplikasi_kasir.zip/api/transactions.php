<?php
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__.'/../config/database.php';
if($_SERVER['REQUEST_METHOD']!=='GET'){http_response_code(405);echo json_encode(['success'=>false,'message'=>'Method tidak didukung.']);exit;}
try{$s=$pdo->query('SELECT id,total,payment,change_amount,created_at FROM transactions ORDER BY id DESC LIMIT 20');echo json_encode(['success'=>true,'data'=>$s->fetchAll()]);}catch(Throwable $e){http_response_code(500);echo json_encode(['success'=>false,'message'=>'Gagal mengambil riwayat transaksi.']);}
