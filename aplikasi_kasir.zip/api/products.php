<?php
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__.'/../config/database.php';
$method=$_SERVER['REQUEST_METHOD'];
try {
 if($method==='GET'){ $stmt=$pdo->query('SELECT id,name,price FROM products ORDER BY name ASC'); echo json_encode(['success'=>true,'data'=>$stmt->fetchAll()]); exit; }
 if($method==='POST'){ $in=json_decode(file_get_contents('php://input'),true); $name=trim($in['name']??''); $price=(int)($in['price']??0); if($name===''||$price<=0){http_response_code(422);echo json_encode(['success'=>false,'message'=>'Nama produk dan harga harus diisi dengan benar.']);exit;} $s=$pdo->prepare('INSERT INTO products(name,price) VALUES(:name,:price)');$s->execute([':name'=>$name,':price'=>$price]);echo json_encode(['success'=>true,'message'=>'Produk berhasil ditambahkan.']);exit; }
 if($method==='PUT'){ $in=json_decode(file_get_contents('php://input'),true); $id=(int)($in['id']??0);$name=trim($in['name']??'');$price=(int)($in['price']??0);if($id<=0||$name===''||$price<=0){http_response_code(422);echo json_encode(['success'=>false,'message'=>'Data produk tidak valid.']);exit;} $s=$pdo->prepare('UPDATE products SET name=:name,price=:price WHERE id=:id');$s->execute([':name'=>$name,':price'=>$price,':id'=>$id]);echo json_encode(['success'=>true,'message'=>'Produk berhasil diperbarui.']);exit; }
 if($method==='DELETE'){ $in=json_decode(file_get_contents('php://input'),true);$id=(int)($in['id']??0);if($id<=0){http_response_code(422);echo json_encode(['success'=>false,'message'=>'ID produk tidak valid.']);exit;} $s=$pdo->prepare('DELETE FROM products WHERE id=:id');$s->execute([':id'=>$id]);echo json_encode(['success'=>true,'message'=>'Produk berhasil dihapus.']);exit; }
 http_response_code(405);echo json_encode(['success'=>false,'message'=>'Method tidak didukung.']);
} catch(Throwable $e){http_response_code(500);echo json_encode(['success'=>false,'message'=>'Terjadi kesalahan pada server.']);}
