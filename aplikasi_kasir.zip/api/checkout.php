<?php
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__.'/../config/database.php';
if($_SERVER['REQUEST_METHOD']!=='POST'){http_response_code(405);echo json_encode(['success'=>false,'message'=>'Method tidak didukung.']);exit;}
try{
 $in=json_decode(file_get_contents('php://input'),true);$cart=$in['cart']??[];$payment=(int)($in['payment']??0);
 if(!is_array($cart)||count($cart)===0){http_response_code(422);echo json_encode(['success'=>false,'message'=>'Keranjang masih kosong.']);exit;}
 $ids=array_values(array_unique(array_filter(array_map(fn($i)=>(int)($i['id']??0),$cart)))); if(!$ids){http_response_code(422);echo json_encode(['success'=>false,'message'=>'Produk tidak valid.']);exit;}
 $ph=implode(',',array_fill(0,count($ids),'?'));$s=$pdo->prepare("SELECT id,name,price FROM products WHERE id IN ($ph)");$s->execute($ids);$products=[];foreach($s->fetchAll() as $p){$products[(int)$p['id']]=$p;}
 $normalized=[];$total=0; foreach($cart as $i){$id=(int)($i['id']??0);$qty=(int)($i['qty']??0);if($id<=0||$qty<=0||!isset($products[$id]))continue;$p=$products[$id];$sub=(int)$p['price']*$qty;$total+=$sub;$normalized[]=['id'=>$id,'name'=>$p['name'],'price'=>(int)$p['price'],'qty'=>$qty,'subtotal'=>$sub];}
 if($total<=0){http_response_code(422);echo json_encode(['success'=>false,'message'=>'Keranjang tidak valid.']);exit;} if($payment<$total){http_response_code(422);echo json_encode(['success'=>false,'message'=>'Uang pembeli kurang.','total'=>$total]);exit;}
 $change=$payment-$total;$pdo->beginTransaction();$s=$pdo->prepare('INSERT INTO transactions(total,payment,change_amount) VALUES(:total,:payment,:change_amount)');$s->execute([':total'=>$total,':payment'=>$payment,':change_amount'=>$change]);$tid=(int)$pdo->lastInsertId();$d=$pdo->prepare('INSERT INTO transaction_details(transaction_id,product_id,product_name,price,qty,subtotal) VALUES(:transaction_id,:product_id,:product_name,:price,:qty,:subtotal)');foreach($normalized as $i){$d->execute([':transaction_id'=>$tid,':product_id'=>$i['id'],':product_name'=>$i['name'],':price'=>$i['price'],':qty'=>$i['qty'],':subtotal'=>$i['subtotal']]);}$pdo->commit();echo json_encode(['success'=>true,'message'=>'Transaksi berhasil disimpan.','transaction_id'=>$tid,'total'=>$total,'payment'=>$payment,'change'=>$change]);
}catch(Throwable $e){if($pdo->inTransaction())$pdo->rollBack();http_response_code(500);echo json_encode(['success'=>false,'message'=>'Transaksi gagal diproses.']);}
