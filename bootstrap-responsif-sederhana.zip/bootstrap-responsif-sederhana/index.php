<!doctype html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Belajar Bootstrap - Website Responsif</title>
    <meta name="description" content="Eksperimen sederhana membuat website responsif menggunakan Bootstrap 5.3.8.">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css"
          rel="stylesheet"
          integrity="sha384-sRIl4kxILFvY47J16cr9ZwB07vP4J8+LH7qKQnuqkuIAvNWLzeN8tE5YBujZqJLB"
          crossorigin="anonymous">
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>

<nav class="navbar navbar-expand-lg bg-dark navbar-dark sticky-top shadow-sm">
    <div class="container">
        <a class="navbar-brand fw-bold" href="#">Belajar Bootstrap</a>

        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mainNav"
                aria-controls="mainNav" aria-expanded="false" aria-label="Buka navigasi">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="mainNav">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item"><a class="nav-link active" href="#beranda">Beranda</a></li>
                <li class="nav-item"><a class="nav-link" href="#fitur">Fitur</a></li>
                <li class="nav-item"><a class="nav-link" href="#kontak">Kontak</a></li>
            </ul>
        </div>
    </div>
</nav>

<header id="beranda" class="hero-section py-5">
    <div class="container py-lg-5">
        <div class="row align-items-center g-4">
            <div class="col-lg-7">
                <span class="badge text-bg-primary mb-3">Eksperimen Web Development</span>
                <h1 class="display-5 fw-bold mb-3">Membuat Website Responsif dengan Bootstrap</h1>
                <p class="lead text-secondary mb-4">
                    Halaman sederhana untuk mencoba grid, card, navbar, form, dan breakpoint responsif Bootstrap.
                </p>
                <div class="d-flex flex-wrap gap-2">
                    <a href="#fitur" class="btn btn-primary btn-lg">Lihat Fitur</a>
                    <a href="#kontak" class="btn btn-outline-dark btn-lg">Coba Form</a>
                </div>
            </div>
            <div class="col-lg-5">
                <div class="hero-card p-4 p-lg-5 bg-white border rounded-4 shadow-sm">
                    <div class="small text-uppercase text-secondary fw-semibold mb-2">Alur eksperimen</div>
                    <div class="d-flex align-items-center gap-3 mb-3">
                        <span class="step-badge">1</span>
                        <div>
                            <div class="fw-semibold">Grid</div>
                            <div class="small text-secondary">Mengatur layout responsif</div>
                        </div>
                    </div>
                    <div class="d-flex align-items-center gap-3 mb-3">
                        <span class="step-badge">2</span>
                        <div>
                            <div class="fw-semibold">Komponen</div>
                            <div class="small text-secondary">Navbar, card, button, form</div>
                        </div>
                    </div>
                    <div class="d-flex align-items-center gap-3">
                        <span class="step-badge">3</span>
                        <div>
                            <div class="fw-semibold">Pengujian</div>
                            <div class="small text-secondary">Desktop, tablet, dan mobile</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</header>

<section id="fitur" class="py-5">
    <div class="container">
        <div class="text-center mb-5">
            <span class="text-primary fw-semibold">Percobaan</span>
            <h2 class="fw-bold mt-2">Komponen yang Digunakan</h2>
            <p class="text-secondary mb-0">Contoh sederhana untuk melihat bagaimana layout berubah mengikuti ukuran layar.</p>
        </div>

        <div class="row row-cols-1 row-cols-md-2 row-cols-lg-3 g-4">
            <div class="col">
                <div class="card h-100 border-0 shadow-sm rounded-4 overflow-hidden">
                    <div class="card-body p-4">
                        <div class="icon-box bg-primary-subtle text-primary mb-3">01</div>
                        <h3 class="h5 fw-bold">Grid Responsif</h3>
                        <p class="text-secondary mb-0">
                            Kolom dibuat bertumpuk pada layar kecil dan melebar pada layar yang lebih besar.
                        </p>
                    </div>
                </div>
            </div>

            <div class="col">
                <div class="card h-100 border-0 shadow-sm rounded-4 overflow-hidden">
                    <div class="card-body p-4">
                        <div class="icon-box bg-success-subtle text-success mb-3">02</div>
                        <h3 class="h5 fw-bold">Komponen UI</h3>
                        <p class="text-secondary mb-0">
                            Navbar, card, badge, button, dan form digunakan tanpa perlu membangun semuanya dari nol.
                        </p>
                    </div>
                </div>
            </div>

            <div class="col">
                <div class="card h-100 border-0 shadow-sm rounded-4 overflow-hidden">
                    <div class="card-body p-4">
                        <div class="icon-box bg-warning-subtle text-warning-emphasis mb-3">03</div>
                        <h3 class="h5 fw-bold">Mobile First</h3>
                        <p class="text-secondary mb-0">
                            Layout dirancang mulai dari layar kecil lalu menyesuaikan diri ke viewport yang lebih besar.
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="py-5 bg-light-subtle">
    <div class="container">
        <div class="row align-items-center g-4">
            <div class="col-lg-6">
                <div class="p-4 bg-white border rounded-4 shadow-sm">
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <span class="fw-semibold">Pengujian Responsif</span>
                        <span class="badge text-bg-success">Aktif</span>
                    </div>
                    <div class="ratio ratio-16x9 rounded-3 overflow-hidden bg-dark-subtle">
                        <div class="d-flex align-items-center justify-content-center text-center p-4">
                            <div>
                                <div class="display-6 fw-bold">12 / 12</div>
                                <div class="text-secondary">Grid Bootstrap menggunakan sistem 12 kolom.</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-6">
                <span class="text-primary fw-semibold">Apa yang diuji?</span>
                <h2 class="fw-bold mt-2">Satu halaman, beberapa ukuran layar</h2>
                <p class="text-secondary">
                    Gunakan DevTools browser untuk mengubah viewport dan amati bagaimana navbar, card, serta kolom
                    menyesuaikan ukurannya.
                </p>
                <ul class="list-group list-group-flush rounded-3 border">
                    <li class="list-group-item bg-white">Desktop: tiga card dalam satu baris</li>
                    <li class="list-group-item bg-white">Tablet: dua card dalam satu baris</li>
                    <li class="list-group-item bg-white">Mobile: satu card dalam satu baris</li>
                </ul>
            </div>
        </div>
    </div>
</section>

<section id="kontak" class="py-5">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-7">
                <div class="p-4 p-lg-5 bg-white border rounded-4 shadow-sm">
                    <div class="text-center mb-4">
                        <span class="text-primary fw-semibold">Form Percobaan</span>
                        <h2 class="fw-bold mt-2">Form Sederhana</h2>
                        <p class="text-secondary mb-0">Bagian ini digunakan untuk mencoba komponen form Bootstrap.</p>
                    </div>

                    <form id="demoForm" novalidate>
                        <div class="mb-3">
                            <label for="nama" class="form-label">Nama</label>
                            <input type="text" class="form-control" id="nama" placeholder="Masukkan nama" required>
                        </div>

                        <div class="mb-3">
                            <label for="email" class="form-label">Email</label>
                            <input type="email" class="form-control" id="email" placeholder="nama@example.com" required>
                        </div>

                        <div class="mb-3">
                            <label for="pesan" class="form-label">Pesan</label>
                            <textarea class="form-control" id="pesan" rows="4" placeholder="Tulis pesan..." required></textarea>
                        </div>

                        <button type="submit" class="btn btn-primary w-100">Kirim</button>
                        <div id="formMessage" class="alert alert-success mt-3 d-none" role="alert">
                            Form berhasil diuji. Tidak ada data yang dikirim ke server.
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</section>

<footer class="py-4 border-top bg-dark text-white">
    <div class="container d-flex flex-column flex-md-row justify-content-between align-items-center gap-2">
        <div class="small">© <span id="year"></span> Belajar Bootstrap</div>
        <div class="small text-white-50">Eksperimen website responsif dengan Bootstrap</div>
    </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-FKyoEForCGlyvwx9Hj09JcYn3nv7wiPVlz7YYwJrWVcXK/BmnVDxM+D2scQbITxI"
        crossorigin="anonymous"></script>
<script src="assets/js/app.js"></script>
</body>
</html>
