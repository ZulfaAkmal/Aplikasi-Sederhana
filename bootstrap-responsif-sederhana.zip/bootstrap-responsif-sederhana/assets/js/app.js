(() => {
    const year = document.getElementById('year');
    if (year) {
        year.textContent = new Date().getFullYear();
    }

    const form = document.getElementById('demoForm');
    const message = document.getElementById('formMessage');

    if (!form || !message) return;

    form.addEventListener('submit', (event) => {
        event.preventDefault();

        if (!form.checkValidity()) {
            form.classList.add('was-validated');
            return;
        }

        message.classList.remove('d-none');
        form.reset();
        form.classList.remove('was-validated');
    });
})();
