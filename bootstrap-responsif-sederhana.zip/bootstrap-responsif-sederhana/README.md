# Bootstrap Responsif Sederhana

Project eksperimen kecil menggunakan Bootstrap 5.3.8, PHP, HTML, CSS, dan JavaScript.

## Teknologi

- PHP native (dipakai sebagai entry point `index.php`)
- Bootstrap 5.3.8 via jsDelivr CDN
- HTML5
- CSS custom
- JavaScript vanilla

## Menjalankan di XAMPP

1. Simpan folder `bootstrap-responsif-sederhana` ke `C:\xampp\htdocs\`.
2. Jalankan Apache dari XAMPP.
3. Buka:
   `http://localhost/bootstrap-responsif-sederhana/`

Tidak membutuhkan database.

## Pengujian untuk artikel

Gunakan browser DevTools untuk menguji beberapa ukuran viewport:

- Mobile: di bawah 576px
- Tablet: sekitar 768px atau lebih
- Desktop: 992px atau lebih

Yang dapat diamati:

- Navbar berubah menjadi menu toggle pada layar kecil.
- Card menggunakan 1 kolom pada mobile, 2 pada ukuran medium, dan 3 pada ukuran large.
- Tombol pada hero menjadi penuh pada layar sangat kecil.

Referensi resmi:
https://getbootstrap.com/docs/5.3/
